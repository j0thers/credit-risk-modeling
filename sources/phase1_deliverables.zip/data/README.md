# Datos — Fase 1

Fuente: Yeh, I. (2009), Default of Credit Card Clients, UCI, DOI 10.24432/C55S3H, CC BY 4.0. https://doi.org/10.24432/C55S3H. Referencia: Yeh y Lien (2009), DOI 10.1016/j.eswa.2007.12.020, sección 3.1. Taiwán, abril–septiembre de 2005; objetivo octubre de 2005, horizonte de un mes. Valores monetarios en dólares taiwaneses (NTD).

## Auditoría
Excel: 30002 filas físicas, 25 columnas, dos encabezados. Datos: 30000 clientes, 23 predictores, ID y objetivo. Todos los valores son enteros; 0 None, NaN y cadenas vacías. ID único; 0 duplicados completos, 35 adicionales sin ID y 56 adicionales considerando solo predictores. No eliminar perfiles coincidentes sin evidencia. Objetivo: 6636 incumplimientos (22.12%), 23364 no incumplimientos. No existe PAY_1.

EDUCATION 0/5/6 (345 clientes), MARRIAGE 0 (54 clientes) y PAY -2/0 no están definidos por las fuentes originales. No asumir que -2 significa ausencia total de actividad. PAY_0=-2: 2759 clientes, 2065 con BILL_AMT1 distinto de cero, 1847 con PAY_AMT1 distinto de cero, 2238 con al menos uno distinto de cero. 1930 clientes presentan facturación negativa en algún mes y 3931 superan su límite en algún mes. No son errores demostrados. El artículo reporta 25000 observaciones y 5529 incumplimientos, además de una inconsistencia en el porcentaje de no incumplimiento (87.88%). No se conoce la explicación de la diferencia muestral.

## Limpieza inicial
Se descarta el encabezado académico redundante, se excluye ID y se renombra el objetivo a DEFAULT_PAYMENT_NEXT_MONTH; se mantienen orden y valores de las 30000 observaciones. No se imputan, recodifican, recortan ni escalan datos. CSV UTF-8, 30000 x 24. Se preserva el Excel original. Los dtypes int64 se verifican tras conversión exacta; CSV no almacena tipos.

## Propuestas posteriores
Separar categorías desconocidas de las categorías documentadas; analizar codificación categórica de PAY; conservar saldos negativos y sobregiros, estudiar indicadores y transformaciones robustas únicamente en train; no usar log directo sobre valores negativos. Auditar coincidencias de perfiles entre particiones como sensibilidad. No asumir causalidad ni extrapolar resultados a Colombia. No se dispone de LGD/EAD observadas ni de microdatos de transacciones; el objetivo no equivale necesariamente a default regulatorio.

## Validación
Auditoría descriptiva global solicitada antes de fijar particiones, exclusivamente para integridad/documentación; no usar sus estadísticos para decisiones de modelado. split_indices.npz contiene posiciones de fila base cero, en el orden del CSV: train 21000 (4645 positivos), validation 4500 (995), test 4500 (996). Dos train_test_split estratificados con random_state=42: 70/30 y 50/50 del remanente. No inspeccionar test por separado hasta evaluación final. Ajustar Pipeline/ColumnTransformer exclusivamente en entrenamiento; validación cruzada estratificada solo en train. No walk-forward. La exposición previa a agregados globales impide calificar el test como completamente ciego.

## Reproducción
`python audit_phase1.py "default of credit card clients.xls" --out phase1` (Linux con libfreexl.so.1, pandas, numpy y scikit-learn). El lector FreeXL se usó porque xlrd no estaba disponible. Resultados: quality.csv, frequencies.csv, descriptive.csv, anomalies.csv, credit_clients_clean.csv, split_indices.npz. Desviación estándar muestral, percentiles lineales, asimetría y exceso de curtosis ajustados de pandas. Las tablas decimales se redondean solo en presentación.
