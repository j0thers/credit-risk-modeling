import ctypes as c
from pathlib import Path
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split

def read_xls(path):
    # FreeXL reads legacy BIFF cells without coercing empty strings to NA.
    lib=c.CDLL('libfreexl.so.1')
    class Value(c.Union):
        _fields_=[('i',c.c_int),('d',c.c_double),('s',c.c_char_p)]
    class Cell(c.Structure):
        _fields_=[('t',c.c_ubyte),('v',Value)]
    h=c.c_void_p(); assert lib.freexl_open(str(path).encode(),c.byref(h))==0
    try:
        assert lib.freexl_select_active_worksheet(h,0)==0
        r=c.c_uint(); k=c.c_ushort(); assert lib.freexl_worksheet_dimensions(h,c.byref(r),c.byref(k))==0
        rows=[]; cell=Cell()
        for i in range(r.value):
            row=[]
            for j in range(k.value):
                assert lib.freexl_get_cell_value(h,i,j,c.byref(cell))==0
                row.append(None if cell.t==101 else cell.v.i if cell.t==102 else cell.v.d if cell.t==103 else cell.v.s.decode('utf-8'))
            rows.append(row)
        return rows
    finally: lib.freexl_close(h)

def audit(path, out):
    out=Path(out); out.mkdir(parents=True,exist_ok=True)
    rows=read_xls(path); print('RAW',len(rows),len(rows[0]),rows[:2]); raw=pd.DataFrame(rows[2:],columns=rows[1],dtype=object)
    quality=pd.DataFrame({'None':raw.apply(lambda s:s.map(lambda x:x is None).sum()),'NaN':raw.apply(lambda s:s.map(lambda x:isinstance(x,float) and np.isnan(x)).sum()),'empty':raw.apply(lambda s:s.map(lambda x:isinstance(x,str) and not x.strip()).sum())})
    df=raw.apply(pd.to_numeric); assert (df%1==0).all().all(); df=df.astype('int64'); quality['dtype']=df.dtypes.astype(str); print(quality.to_string()); quality.to_csv(out/'quality.csv')
    target='default payment next month'; pay=['PAY_0','PAY_2','PAY_3','PAY_4','PAY_5','PAY_6']; cats=['SEX','EDUCATION','MARRIAGE',*pay,target]; numeric=['AGE','LIMIT_BAL']+[f'{p}{i}' for p in ['BILL_AMT','PAY_AMT'] for i in range(1,7)]
    clean=df.drop(columns='ID').rename(columns={target:'DEFAULT_PAYMENT_NEXT_MONTH'}); print('SHAPE',df.shape,'DUP',df.duplicated().sum(),df.ID.duplicated().sum(),clean.duplicated().sum(),clean.drop(columns='DEFAULT_PAYMENT_NEXT_MONTH').duplicated().sum()); assert df.ID.is_unique
    freq=pd.concat([df[x].value_counts().sort_index().rename('n').to_frame().assign(pct=lambda a:a.n*100/len(df),variable=x) for x in cats]).rename_axis('code').reset_index(); print(freq.to_string(index=False)); freq.to_csv(out/'frequencies.csv',index=False)
    desc=df[numeric].describe(percentiles=[.01,.25,.5,.75,.99]).T; desc['skew']=df[numeric].skew(); desc['kurtosis']=df[numeric].kurt(); print(desc.to_string(float_format=lambda x:f'{x:.6f}')); desc.to_csv(out/'descriptive.csv')
    bills=df[[f'BILL_AMT{i}' for i in range(1,7)]]; neg=bills.lt(0); over=bills.gt(df.LIMIT_BAL,axis=0); anomalies=pd.DataFrame({'negative':neg.sum(),'over_limit':over.sum(),'max_excess':(bills.sub(df.LIMIT_BAL,axis=0)).max()}); print(anomalies,'ANY',neg.any(axis=1).sum(),over.any(axis=1).sum(),'TOTAL',neg.sum().sum(),over.sum().sum()); anomalies.to_csv(out/'anomalies.csv')
    mask=df.PAY_0.eq(-2); b=df.BILL_AMT1.ne(0); p=df.PAY_AMT1.ne(0); print('PAY0',mask.sum(),(mask&b).sum(),(mask&p).sum(),(mask&(b|p)).sum(),(mask&b&p).sum(),(mask&~b&~p).sum()); print('PAY0 all months', (mask&bills.ne(0).any(axis=1)).sum(),(mask&df[[f'PAY_AMT{i}' for i in range(1,7)]].ne(0).any(axis=1)).sum())
    clean.to_csv(out/'credit_clients_clean.csv',index=False)
    ix=np.arange(len(df)); train,rest=train_test_split(ix,test_size=.3,stratify=df[target],random_state=42); val,test=train_test_split(rest,test_size=.5,stratify=df[target].iloc[rest],random_state=42); print('SPLIT',[(len(i),int(df[target].iloc[i].sum())) for i in (train,val,test)]); np.savez(out/'split_indices.npz',train=train,validation=val,test=test)
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(); p.add_argument('input',type=Path); p.add_argument('--out',type=Path,default=Path('phase1')); a=p.parse_args(); audit(a.input,a.out)
