import argparse, zipfile
import mpmath as mp
from pathlib import Path
import numpy as np, pandas as pd
from scipy.stats import chi2_contingency, mannwhitneyu, binomtest, gaussian_kde, chi2
from sklearn.metrics import roc_auc_score, average_precision_score
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def run(source,out):
    out=Path(out); f=out/'figures'; r=out/'reports'; f.mkdir(parents=True,exist_ok=True); r.mkdir(parents=True,exist_ok=True)
    if str(source).endswith('.zip'):
        with zipfile.ZipFile(source) as z:
            d=pd.read_csv(z.open('data/phase1/credit_clients_clean.csv')); splits=np.load(z.open('data/phase1/split_indices.npz'))
            assert sorted(np.concatenate([splits[k] for k in ['train','validation','test']]).tolist())==list(range(len(d)))
    else: d=pd.read_csv(source)
    d=d.drop(columns='ID',errors='ignore').rename(columns={'DEFAULT_PAYMENT_NEXT_MONTH':'default'})
    d.EDUCATION=d.EDUCATION.replace({0:4,5:4,6:4}); d.MARRIAGE=d.MARRIAGE.replace({0:3})
    assert d.shape==(30000,24) and not d.isna().any().any()
    y=d.default; n=len(y); p=y.mean(); ci=binomtest(int(y.sum()),n).proportion_ci(method='exact'); print('TARGET',y.value_counts().to_dict(),p,ci)
    pd.DataFrame([dict(n=n,defaults=y.sum(),rate=p,ci_lower=ci.low,ci_upper=ci.high)]).to_csv(r/'target.csv',index=False)
    pay=['PAY_6','PAY_5','PAY_4','PAY_3','PAY_2','PAY_0']; cats=['SEX','EDUCATION','MARRIAGE']; tables=[]; tests=[]
    for v in cats+pay:
        t=pd.crosstab(d[v],y); s,pv,df,e=chi2_contingency(t,correction=False); tests.append(dict(variable=v,chi2=s,p=pv,p_high_precision=mp.nstr(mp.gammainc(df/2,s/2,mp.inf,regularized=True),17),log_p=float(mp.log(mp.gammainc(df/2,s/2,mp.inf,regularized=True))),df=df,V=np.sqrt(s/n),min_expected=e.min(),expected_lt5=(e<5).sum())); t['n']=t.sum(axis=1); t['rate']=t[1]/t.n; tables.append(t.reset_index(names='code').assign(variable=v))
    tab=pd.concat(tables); test=pd.DataFrame(tests); tab.to_csv(r/'contingency.csv',index=False); test.to_csv(r/'chi_square.csv',index=False); print(tab.to_string(index=False)); print(test.to_string(index=False))
    transitions=[]; persist=[]
    for a,b in zip(pay,pay[1:]):
        t=pd.crosstab(d[a],d[b]); frac=t.div(t.sum(axis=1),axis=0); transitions.append(t.stack().rename('n').to_frame().join(frac.stack().rename('probability')).reset_index().rename(columns={a:'from_state',b:'to_state'}).assign(from_month=a,to_month=b)); tmp=pd.crosstab(d[a]>0,d[b]>0); persist.append(dict(pair=a+'→'+b,previous_late=tmp.loc[True].sum(),persistent=tmp.loc[True,True],p_late_given_late=tmp.loc[True,True]/tmp.loc[True].sum(),p_late_given_not_late=tmp.loc[False,True]/tmp.loc[False].sum()))
    pd.concat(transitions).to_csv(r/'transitions.csv',index=False); pd.DataFrame(persist).to_csv(r/'persistence.csv',index=False); print(pd.DataFrame(persist).to_string(index=False))
    nums=['AGE','LIMIT_BAL']+[f'{v}{i}' for v in ['BILL_AMT','PAY_AMT'] for i in range(1,7)]
    d['utilization']=d.BILL_AMT1/d.LIMIT_BAL; d['payment_ratio']=d.PAY_AMT1/d.BILL_AMT2.where(d.BILL_AMT2>0)
    desc=[]; mw=[]
    for v in nums+['utilization','payment_ratio']:
        groups=[d.loc[y==k,v].dropna() for k in [0,1]]
        for k,x in enumerate(groups):
            q1,q3=x.quantile([.25,.75]); desc.append(dict(variable=v,default=k,n=len(x),mean=x.mean(),sd=x.std(),median=x.median(),q1=q1,q3=q3,iqr=q3-q1))
        a,b=groups; u=mannwhitneyu(a,b,alternative='two-sided',method='asymptotic'); auc=1-u.statistic/(len(a)*len(b)); mw.append(dict(variable=v,U_class0=u.statistic,p=u.pvalue,auc_raw=auc,auc_risk_oriented=max(auc,1-auc)))
    desc=pd.DataFrame(desc); mw=pd.DataFrame(mw); desc.to_csv(r/'descriptive.csv',index=False); mw.to_csv(r/'mann_whitney.csv',index=False); print(desc.to_string(index=False)); print(mw.to_string(index=False))
    ratios=[]
    for v,sign in [('utilization',1),('payment_ratio',-1)]:
        ok=d[v].notna(); ratios.append(dict(variable=v,n=ok.sum(),excluded=(~ok).sum(),default_rate=y[ok].mean(),excluded_default_rate=y[~ok].mean(),auc=roc_auc_score(y[ok],sign*d.loc[ok,v]),average_precision=average_precision_score(y[ok],sign*d.loc[ok,v])))
    print('RATIOS',ratios); pd.DataFrame(ratios).to_csv(r/'ratios.csv',index=False)
    corrcols=['LIMIT_BAL','AGE']+pay[::-1]+nums[2:]; pairs=[]; matrices=[]
    for method in ['pearson','spearman']:
        c=d[corrcols].corr(method=method); matrices.append(c); c.to_csv(r/f'{method}.csv'); pairs.extend(dict(method=method,a=a,b=b,r=c.loc[a,b]) for i,a in enumerate(c) for b in c.columns[i+1:] if abs(c.loc[a,b])>.75)
    pd.DataFrame(pairs).to_csv(r/'high_correlations.csv',index=False); print(pd.DataFrame(pairs).to_string(index=False))
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    def save(fig,name):
        fig.tight_layout(); fig.savefig(f/name,dpi=300,bbox_inches='tight'); plt.close(fig)
    fig,axs=plt.subplots(2,2,figsize=(11,8)); axs=axs.ravel(); axs[0].bar(['0','1'],y.value_counts().sort_index()); axs[0].set(title='Incumplimiento observado',ylabel='Clientes');
    for ax,v in zip(axs[1:],cats):
        t=tab[tab.variable==v]; ax.bar(t.code.astype(str),100*t.rate); ax.axhline(100*p,ls='--'); ax.set(title=v,ylabel='Default (%)',xlabel='Código');
        for i,(_,row) in enumerate(t.iterrows()): ax.text(i,100*row.rate,f'{100*row.rate:.1f}%\nn={row.n}',ha='center',va='bottom',fontsize=8)
        ax.set_ylim(0,max(100*t.rate)*1.3)
    save(fig,'01_target_and_demographics.png')
    fig,axs=plt.subplots(2,2,figsize=(12,8));
    for i,v in enumerate(['LIMIT_BAL','AGE']):
        scale=1000 if v=='LIMIT_BAL' else 1; groups=[d.loc[y==k,v]/scale for k in [0,1]]; grid=np.linspace(min(x.min() for x in groups),max(x.max() for x in groups),300); bins=np.linspace(grid.min(),grid.max(),41)
        for k,x in enumerate(groups): axs[i,0].hist(x,bins=bins,density=True,alpha=.35,label=f'Default {k}'); axs[i,0].plot(grid,gaussian_kde(x)(grid))
        axs[i,0].legend(); axs[i,0].set(ylabel='Densidad',xlabel=v+(' (miles NTD)' if scale==1000 else ' (años)')); axs[i,1].boxplot(groups,labels=['0','1'],vert=False,showfliers=True); axs[i,1].set(xlabel=v+(' (miles NTD)' if scale==1000 else ' (años)'),ylabel='Default')
    save(fig,'02_limit_bal_age_dist.png')
    fig,axs=plt.subplots(2,1,figsize=(12,9)); t=tab[tab.variable=='PAY_0']; axs[0].bar(t.code.astype(str),100*t.rate); axs[0].axhline(100*p,ls='--'); axs[0].set(ylabel='Default (%)',title='Septiembre: PAY_0',ylim=(0,105));
    for i,(_,row) in enumerate(t.iterrows()): axs[0].text(i,100*row.rate+2,f'n={row.n}',ha='center',fontsize=8)
    pivot=tab[tab.variable.isin(pay)].pivot(index='code',columns='variable',values='rate').reindex(columns=pay); im=axs[1].imshow(pivot*100,aspect='auto',vmin=0,vmax=100); axs[1].set_xticks(range(6),['Abr','May','Jun','Jul','Ago','Sep']); axs[1].set_yticks(range(len(pivot)),pivot.index); axs[1].set(ylabel='Código de pago',title='Tasa condicional de default por mes (%)');
    for i in range(len(pivot)):
        for j in range(6):
            v=pivot.iloc[i,j]; axs[1].text(j,i,'—' if pd.isna(v) else f'{v*100:.1f}',ha='center',va='center',color='white' if pd.notna(v) and v<.5 else 'black',fontsize=8)
    fig.colorbar(im,ax=axs[1]); save(fig,'03_payment_status_default_rate.png')
    fig,axs=plt.subplots(1,2,figsize=(17,8));
    for ax,c,method in zip(axs,matrices,['Pearson','Spearman']):
        im=ax.imshow(c,vmin=-1,vmax=1,cmap='RdBu_r'); ax.set_xticks(range(len(c)),c.columns,rotation=90,fontsize=8); ax.set_yticks(range(len(c)),c.columns,fontsize=8); ax.set_title(method)
        for i in range(len(c)):
            for j in range(len(c)):
                if i!=j and abs(c.iloc[i,j])>.75: ax.text(j,i,f'{c.iloc[i,j]:.2f}',ha='center',va='center',fontsize=6,color='white')
        fig.colorbar(im,ax=ax,shrink=.7)
    save(fig,'04_correlation_heatmap.png')
if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('source'); p.add_argument('--out',default='.'); a=p.parse_args(); run(a.source,a.out)
